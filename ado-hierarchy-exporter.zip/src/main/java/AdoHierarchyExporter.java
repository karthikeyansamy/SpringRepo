import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import com.fasterxml.jackson.databind.*;

public class AdoHierarchyExporter {

    private static final String ORGANIZATION = "your-org";   
    private static final String PAT = "your-pat"; 
    private static final int PAGE_SIZE = 200; 

    private static final ObjectMapper mapper = new ObjectMapper();

    static class WorkItemNode {
        int id;
        String title;
        String type;
        String projectName;
        String areaPath;
        String assignedTo;
        String createdBy;
        List<WorkItemNode> children = new ArrayList<>();

        WorkItemNode(int id) {
            this.id = id;
        }
    }

    public static void main(String[] args) throws Exception {
        List<String> projects = fetchProjects();
        Map<Integer, WorkItemNode> allNodes = new HashMap<>();
        List<String[]> csvRows = new ArrayList<>();
        Set<Integer> allIds = new HashSet<>();

        // Step 1: Get all links
        for (String project : projects) {
            System.out.println("Fetching links for project: " + project);
            int skip = 0;
            while (true) {
                List<Map<String, Object>> batch = runWiqlForLinks(project, skip, PAGE_SIZE);
                if (batch.isEmpty()) break;

                for (Map<String, Object> link : batch) {
                    Integer sourceId = (Integer) link.get("sourceId");
                    Integer targetId = (Integer) link.get("targetId");
                    String relation = (String) link.get("relation");

                    if (sourceId != null) allIds.add(sourceId);
                    if (targetId != null) allIds.add(targetId);

                    if (sourceId != null) allNodes.putIfAbsent(sourceId, new WorkItemNode(sourceId));
                    if (targetId != null) allNodes.putIfAbsent(targetId, new WorkItemNode(targetId));

                    if (sourceId != null && targetId != null) {
                        WorkItemNode parent = allNodes.get(sourceId);
                        WorkItemNode child = allNodes.get(targetId);
                        if (!parent.children.contains(child)) {
                            parent.children.add(child);
                        }
                        csvRows.add(new String[]{
                                sourceId.toString(),
                                targetId.toString(),
                                relation
                        });
                    }
                }
                skip += PAGE_SIZE;
            }
        }

        // Step 2: Fetch details in batches
        List<Integer> idList = new ArrayList<>(allIds);
        for (int i = 0; i < idList.size(); i += 200) {
            List<Integer> batch = idList.subList(i, Math.min(i + 200, idList.size()));
            enrichWorkItems(batch, allNodes);
        }

        // Step 3: Export CSV with enriched fields
        try (PrintWriter pw = new PrintWriter(new File("workitem_links.csv"))) {
            pw.println("ParentId,ChildId,Relation,ParentTitle,ChildTitle,ParentType,ChildType,ParentArea,ChildArea,ParentProject,ChildProject,ParentAssignee,ChildAssignee,ParentReporter,ChildReporter");
            for (String[] row : csvRows) {
                int parentId = Integer.parseInt(row[0]);
                int childId = Integer.parseInt(row[1]);
                String relation = row[2];
                WorkItemNode parent = allNodes.get(parentId);
                WorkItemNode child = allNodes.get(childId);

                String[] outRow = new String[]{
                        String.valueOf(parentId),
                        String.valueOf(childId),
                        relation,
                        safe(parent.title),
                        safe(child.title),
                        safe(parent.type),
                        safe(child.type),
                        safe(parent.areaPath),
                        safe(child.areaPath),
                        safe(parent.projectName),
                        safe(child.projectName),
                        safe(parent.assignedTo),
                        safe(child.assignedTo),
                        safe(parent.createdBy),
                        safe(child.createdBy)
                };
                pw.println(String.join(",", escape(outRow)));
            }
        }

        System.out.println("Exported enriched workitem_links.csv with " + csvRows.size() + " rows.");
    }

    private static List<String> fetchProjects() throws Exception {
        String url = String.format("https://dev.azure.com/%s/_apis/projects?api-version=7.0", ORGANIZATION);
        String response = sendGet(url);
        JsonNode root = mapper.readTree(response);

        List<String> projects = new ArrayList<>();
        if (root.has("value")) {
            for (JsonNode proj : root.get("value")) {
                projects.add(proj.get("name").asText());
            }
        }
        return projects;
    }

    private static List<Map<String, Object>> runWiqlForLinks(String project, int skip, int top) throws Exception {
        String url = String.format(
                "https://dev.azure.com/%s/%s/_apis/wit/wiql?$top=%d&$skip=%d&api-version=7.0",
                ORGANIZATION, project, top, skip);

        String wiqlQuery =
                "SELECT [System.Id], [System.WorkItemType], [System.Title] " +
                "FROM WorkItemLinks " +
                "WHERE Source.[System.TeamProject] = @project " +
                "ORDER BY [System.Id] " +
                "MODE (Recursive, ReturnMatchingChildren)";

        String jsonPayload = mapper.writeValueAsString(Collections.singletonMap("query", wiqlQuery));
        String response = sendPost(url, jsonPayload);
        JsonNode root = mapper.readTree(response);

        List<Map<String, Object>> links = new ArrayList<>();
        if (root.has("workItemRelations")) {
            for (JsonNode rel : root.get("workItemRelations")) {
                Map<String, Object> link = new HashMap<>();
                if (rel.has("source")) link.put("sourceId", rel.get("source").get("id").asInt());
                if (rel.has("target")) link.put("targetId", rel.get("target").get("id").asInt());
                if (rel.has("rel")) link.put("relation", rel.get("rel").asText());
                links.add(link);
            }
        }
        return links;
    }

    private static void enrichWorkItems(List<Integer> ids, Map<Integer, WorkItemNode> allNodes) throws Exception {
        String idList = String.join(",", ids.stream().map(String::valueOf).toArray(String[]::new));
        String url = String.format("https://dev.azure.com/%s/_apis/wit/workitems?ids=%s&$expand=fields&api-version=7.0",
                ORGANIZATION, idList);

        String response = sendGet(url);
        JsonNode root = mapper.readTree(response);

        if (root.has("value")) {
            for (JsonNode wi : root.get("value")) {
                int id = wi.get("id").asInt();
                WorkItemNode node = allNodes.get(id);
                if (node == null) continue;

                JsonNode fields = wi.path("fields");
                node.title = fields.path("System.Title").asText("");
                node.type = fields.path("System.WorkItemType").asText("");
                node.areaPath = fields.path("System.AreaPath").asText("");
                node.projectName = fields.path("System.TeamProject").asText("");
                node.assignedTo = fields.path("System.AssignedTo").path("displayName").asText("");
                node.createdBy = fields.path("System.CreatedBy").path("displayName").asText("");
            }
        }
    }

    private static String sendGet(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        String auth = ":" + PAT;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Authorization", "Basic " + encodedAuth);

        int status = conn.getResponseCode();
        InputStream is = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
        String response = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))
                .lines().reduce("", (acc, line) -> acc + line);
        conn.disconnect();
        if (status < 200 || status >= 300) throw new RuntimeException("HTTP " + status + " -> " + response);
        return response;
    }

    private static String sendPost(String urlStr, String body) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        String auth = ":" + PAT;
        String encodedAuth = Base64.getEncoder().encodeToString(auth.getBytes(StandardCharsets.UTF_8));
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Basic " + encodedAuth);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }

        int status = conn.getResponseCode();
        InputStream is = (status >= 200 && status < 300) ? conn.getInputStream() : conn.getErrorStream();
        String response = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))
                .lines().reduce("", (acc, line) -> acc + line);
        conn.disconnect();
        if (status < 200 || status >= 300) throw new RuntimeException("HTTP " + status + " -> " + response);
        return response;
    }

    private static String[] escape(String[] row) {
        String[] escaped = new String[row.length];
        for (int i = 0; i < row.length; i++) {
            String val = row[i] == null ? "" : row[i];
            if (val.contains(",") || val.contains("\"")) {
                val = "\"" + val.replace("\"", "\"\"") + "\"";
            }
            escaped[i] = val;
        }
        return escaped;
    }

    private static String safe(String s) {
        return (s == null) ? "" : s;
    }
}
