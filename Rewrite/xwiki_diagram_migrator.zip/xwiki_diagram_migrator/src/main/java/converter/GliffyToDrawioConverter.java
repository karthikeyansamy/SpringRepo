package converter;

import java.io.*;

public class GliffyToDrawioConverter {

    public static File convert(File gliffy) throws Exception {

        File output = new File(
            gliffy.getParent(),
            gliffy.getName().replace(".gliffy", ".mxfile")
        );

        ProcessBuilder pb = new ProcessBuilder(
                "drawio",
                "--headless",
                "--import", gliffy.getAbsolutePath(),
                "--export", output.getAbsolutePath()
        );

        pb.redirectErrorStream(true);
        Process p = pb.start();
        p.waitFor();

        if (!output.exists()) {
            throw new RuntimeException("Conversion failed: " + gliffy);
        }
        return output;
    }
}
