package confluence;

import java.net.http.*;
import java.net.URI;
import java.util.Base64;

public class ConfluenceClient {

    private final HttpClient client = HttpClient.newHttpClient();
    private final String auth;

    public ConfluenceClient(String user, String token) {
        this.auth = Base64.getEncoder()
                .encodeToString((user + ":" + token).getBytes());
    }

    public byte[] downloadAttachment(String url) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Authorization", "Basic " + auth)
                .build();

        return client.send(request,
                HttpResponse.BodyHandlers.ofByteArray()).body();
    }
}