package xwiki;

import java.net.http.*;
import java.net.URI;
import java.util.Base64;

public class XWikiClient {

    private final HttpClient client = HttpClient.newHttpClient();
    private final String auth;

    public XWikiClient(String user, String pass) {
        this.auth = Base64.getEncoder()
                .encodeToString((user + ":" + pass).getBytes());
    }

    public void uploadAttachment(
            String pageUrl,
            File file) throws Exception {

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(pageUrl + "/attachments/" + file.getName()))
                .header("Authorization", "Basic " + auth)
                .header("XWiki-Versioning", "true")
                .PUT(HttpRequest.BodyPublishers.ofFile(file.toPath()))
                .build();

        client.send(request,
                HttpResponse.BodyHandlers.discarding());
    }
}
