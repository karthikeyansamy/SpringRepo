import confluence.*;
import converter.*;
import xwiki.*;

import java.io.*;
import java.nio.file.*;

public class MigrationRunner {

    public static void main(String[] args) throws Exception {

        ConfluenceClient confluence =
            new ConfluenceClient("user", "token");

        XWikiClient xwiki =
            new XWikiClient("xwikiUser", "xwikiPass");

        String gliffyUrl =
            "https://confluence/rest/api/content/123/child/attachment/456/download";

        byte[] gliffyData = confluence.downloadAttachment(gliffyUrl);

        File gliffy = Files.write(
                Path.of("diagram.gliffy"),
                gliffyData).toFile();

        File mxfile =
            GliffyToDrawioConverter.convert(gliffy);

        xwiki.uploadAttachment(
            "https://xwiki/rest/wikis/xwiki/spaces/SPACE/pages/Page",
            mxfile
        );

        System.out.println("Migration complete");
    }
}
